import Foundation

protocol ExerciseRepository { func fetchExercises() async throws -> [Exercise] }
protocol TrainingRepository { func fetchPlans() async throws -> [TrainingPlan] }
protocol ProgressRepository { func markExerciseCompleted(_ id: UUID) async throws }
protocol CoachRepository { func submitQuestion(_ question: CoachQuestion) async throws }
protocol AuthServiceProtocol {
    func signIn(email: String, password: String) async throws
    func signOut() async throws
}
enum RepositoryError: Error { case notImplemented }
