import Foundation

enum TrainingType: String, Codable, CaseIterable, Identifiable { case technical, physical; var id: String { rawValue } }
enum Difficulty: String, Codable, CaseIterable, Identifiable { case beginner, intermediate, advanced; var id: String { rawValue } }
enum Equipment: String, Codable, CaseIterable, Identifiable {
    case ball, resistanceBand, balance, mat, bodyweight, cones
    var id: String { rawValue }
    func name(_ bg: Bool) -> String {
        switch self {
        case .ball: return bg ? "Топка" : "Ball"
        case .resistanceBand: return bg ? "Ластик" : "Resistance Band"
        case .balance: return bg ? "Баланс" : "Balance"
        case .mat: return bg ? "Постелка" : "Mat"
        case .bodyweight: return bg ? "Собствено тегло" : "Bodyweight"
        case .cones: return bg ? "Конуси" : "Cones"
        }
    }
}
enum Position: String, Codable, CaseIterable, Identifiable {
    case goalkeeper, centreBack, fullBack, defensiveMidfielder, centralMidfielder, attackingMidfielder, winger, striker
    var id: String { rawValue }
    var displayName: String {
        switch self {
        case .goalkeeper: return "Goalkeeper"; case .centreBack: return "Centre Back"; case .fullBack: return "Full Back"
        case .defensiveMidfielder: return "Defensive Midfielder"; case .centralMidfielder: return "Central Midfielder"
        case .attackingMidfielder: return "Attacking Midfielder"; case .winger: return "Winger"; case .striker: return "Striker"
        }
    }
}
struct Exercise: Identifiable, Codable, Hashable {
    let id: UUID; let titleEN: String; let titleBG: String
    let descriptionEN: String; let descriptionBG: String
    let category: String; let trainingType: TrainingType; let difficulty: Difficulty
    let duration: Int; let sets: Int; let repetitions: Int?
    let equipment: [Equipment]; let instructionsEN: [String]; let instructionsBG: [String]
    var isActive: Bool = true
}
struct TrainingPlan: Identifiable, Codable {
    let id: UUID; let titleEN: String; let titleBG: String
    let descriptionEN: String; let descriptionBG: String
    let weeks: Int; let difficulty: Difficulty; let objectiveEN: String; let objectiveBG: String
    let sessionExerciseIDs: [UUID]
}
struct Achievement: Identifiable, Codable {
    let id: UUID; let titleEN: String; let titleBG: String; let icon: String; let requirement: Int
}
struct PlayerProfile: Codable {
    var name = "Alex"; var age = 14; var position: Position = .winger
    var experience = "Intermediate"; var goals = ["Dribbling", "Acceleration", "Finishing"]
    var dominantFoot = "Right"; var equipment: [Equipment] = [.ball, .cones]
    var preferredDuration = 25; var weeklyFrequency = 4
}
struct CoachQuestion: Identifiable, Codable {
    let id: UUID; let question: String; let category: String; let date: Date; var status: Status
    enum Status: String, Codable { case pending, answered }
}
