import SwiftUI

struct HomeView: View {
    @EnvironmentObject var store: AppStore
    var body: some View {
        ScrollView {
            VStack(spacing:18) {
                HStack {
                    VStack(alignment:.leading) {
                        Text("Good afternoon, \(store.profile.name)!").font(.title.bold())
                        Text(store.t("Keep your streak going!","Продължавай серията си!")).foregroundStyle(.secondary)
                    }
                    Spacer(); Image(systemName:"person.crop.circle.fill").font(.largeTitle)
                }
                Card {
                    let e = store.exercises[0]
                    VStack(alignment:.leading,spacing:12) {
                        Text(store.t("TODAY'S TRAINING","ДНЕШНА ТРЕНИРОВКА")).font(.caption.bold()).foregroundStyle(Color(hex:"00C853"))
                        Text(store.language == .english ? e.titleEN : e.titleBG).font(.title2.bold())
                        Text("\(e.duration) min • \(e.difficulty.rawValue.capitalized)").foregroundStyle(.secondary)
                        NavigationLink { ExerciseDetailView(exercise:e) } label {
                            Text(store.t("START TRAINING","ЗАПОЧНИ ТРЕНИРОВКА")).font(.headline).foregroundStyle(.white)
                                .frame(maxWidth:.infinity).padding().background(Color(hex:"00C853")).clipShape(RoundedRectangle(cornerRadius:14))
                        }
                    }
                }
                Card { Label(store.t("Small improvements every day create great players.","Малките подобрения всеки ден създават големи футболисти."),systemImage:"quote.opening").font(.headline) }
            }.padding()
        }.background(Color(hex:"F5F5F5")).navigationTitle("TrainSmart")
    }
}
struct Card<Content:View>: View {
    @ViewBuilder let content:Content
    var body: some View { content.padding(16).frame(maxWidth:.infinity,alignment:.leading).background(.white).clipShape(RoundedRectangle(cornerRadius:18)).shadow(color:.black.opacity(0.05),radius:8,y:3) }
}
