import SwiftUI

struct ExerciseDetailView: View {
    @EnvironmentObject var store:AppStore
    let exercise:Exercise
    var completed:Bool { store.completedExerciseIDs.contains(exercise.id) }
    var body:some View {
        ScrollView {
            VStack(alignment:.leading,spacing:18) {
                Image(systemName:exercise.trainingType == .technical ? "soccerball" : "figure.run")
                    .font(.system(size:64)).frame(maxWidth:.infinity).padding(35)
                    .background(Color(hex:"4B4B4B")).foregroundStyle(.white).clipShape(RoundedRectangle(cornerRadius:20))
                Text(store.language == .english ? exercise.titleEN : exercise.titleBG).font(.largeTitle.bold())
                Text(store.language == .english ? exercise.descriptionEN : exercise.descriptionBG).foregroundStyle(.secondary)
                Text(store.t("Instructions","Инструкции")).font(.title3.bold())
                ForEach(Array((store.language == .english ? exercise.instructionsEN : exercise.instructionsBG).enumerated()),id:\.offset) { i,s in Label(s,systemImage:"\(i+1).circle.fill") }
                Button { store.complete(exercise) } label {
                    Label(completed ? store.t("Completed","Завършено") : store.t("Complete Exercise","Завърши упражнението"),
                          systemImage:completed ? "checkmark.circle.fill":"checkmark.circle")
                    .font(.headline).frame(maxWidth:.infinity).padding().background(completed ? .gray : Color(hex:"00C853")).foregroundStyle(.white).clipShape(RoundedRectangle(cornerRadius:14))
                }
            }.padding()
        }.background(Color(hex:"F5F5F5"))
    }
}
