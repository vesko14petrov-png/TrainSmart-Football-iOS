import SwiftUI

struct ProfileView:View {
    @EnvironmentObject var store:AppStore
    var body:some View {
        Form {
            Section { HStack { Image(systemName:"person.crop.circle.fill").font(.system(size:64)); VStack(alignment:.leading){Text(store.profile.name).font(.title2.bold());Text("\(store.profile.age) • \(store.profile.position.displayName)").foregroundStyle(.secondary)} } }
            Section(store.t("Player","Играч")) {
                TextField("Name",text:$store.profile.name)
                Stepper("Age: \(store.profile.age)",value:$store.profile.age,in:8...17)
                Picker("Position",selection:$store.profile.position) { ForEach(Position.allCases){Text($0.displayName).tag($0)} }
                Text("Dominant foot: \(store.profile.dominantFoot)")
                Text("Frequency: \(store.profile.weeklyFrequency)x / week")
            }
            Section(store.t("Settings","Настройки")) {
                Picker("Language",selection:$store.language){Text("English").tag(AppLanguage.english);Text("Български").tag(AppLanguage.bulgarian)}
            }
        }.navigationTitle(store.t("Profile","Профил"))
    }
}
