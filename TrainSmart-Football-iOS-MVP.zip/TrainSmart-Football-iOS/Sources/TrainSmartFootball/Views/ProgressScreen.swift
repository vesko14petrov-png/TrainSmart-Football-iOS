import SwiftUI

struct ProgressScreen:View {
    @EnvironmentObject var store:AppStore
    var body:some View {
        ScrollView {
            VStack(spacing:18) {
                HStack {
                    Metric(title:store.t("Streak","Серия"),value:"\(store.streak) days")
                    Metric(title:store.t("Exercises","Упражнения"),value:"\(store.completedCount)")
                }
                Card {
                    VStack(alignment:.leading,spacing:12) {
                        Text(store.t("Weekly Training","Седмична тренировка")).font(.title3.bold())
                        ProgressView(value:0.72).tint(Color(hex:"00C853"))
                        Text("Technical 72%").font(.caption)
                        ProgressView(value:0.63).tint(Color(hex:"00C853"))
                        Text("Physical 63%").font(.caption)
                    }
                }
                Card {
                    VStack(alignment:.leading,spacing:10) {
                        Text(store.t("Achievements","Постижения")).font(.title3.bold())
                        ForEach(store.achievements) { a in Label(store.language == .english ? a.titleEN : a.titleBG,systemImage:a.icon) }
                    }
                }
            }.padding()
        }.background(Color(hex:"F5F5F5")).navigationTitle(store.t("My Progress","Моят напредък"))
    }
}
struct Metric:View {
    let title:String; let value:String
    var body:some View { VStack(alignment:.leading){Text(value).font(.title.bold());Text(title).font(.caption).foregroundStyle(.secondary)}.frame(maxWidth:.infinity,alignment:.leading).padding().background(.white).clipShape(RoundedRectangle(cornerRadius:16)) }
}
