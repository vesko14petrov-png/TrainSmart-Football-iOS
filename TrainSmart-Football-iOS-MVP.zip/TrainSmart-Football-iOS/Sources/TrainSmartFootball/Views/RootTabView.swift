import SwiftUI

struct RootTabView: View {
    @EnvironmentObject var store: AppStore
    var body: some View {
        TabView {
            NavigationStack { HomeView() }.tabItem { Label(store.t("Home","Начало"), systemImage:"house.fill") }
            NavigationStack { TrainingView() }.tabItem { Label(store.t("Training","Тренировки"), systemImage:"soccerball") }
            NavigationStack { ProgressScreen() }.tabItem { Label(store.t("Progress","Напредък"), systemImage:"chart.bar.fill") }
            NavigationStack { CoachView() }.tabItem { Label(store.t("Ask Coach","Питай треньор"), systemImage:"questionmark.bubble.fill") }
            NavigationStack { ProfileView() }.tabItem { Label(store.t("Profile","Профил"), systemImage:"person.fill") }
        }.tint(Color(hex:"00C853"))
    }
}

extension Color {
    init(hex: String) {
        let v = UInt64(hex, radix:16) ?? 0
        self.init(.sRGB, red:Double((v>>16)&255)/255, green:Double((v>>8)&255)/255, blue:Double(v&255)/255, opacity:1)
    }
}
