import SwiftUI

struct TrainingView: View {
    @EnvironmentObject var store: AppStore
    @State private var type:TrainingType = .technical
    @State private var selected:Equipment?
    var filtered:[Exercise] { store.exercises.filter { $0.trainingType == type && (selected == nil || $0.equipment.contains(selected!)) } }

    var body: some View {
        List {
            Picker("",selection:$type) {
                Text(store.t("Technical","Техническа")).tag(TrainingType.technical)
                Text(store.t("Physical","Физическа")).tag(TrainingType.physical)
            }.pickerStyle(.segmented)
            ScrollView(.horizontal,showsIndicators:false) {
                HStack {
                    Button(store.t("All","Всички")) { selected=nil }
                    ForEach(Equipment.allCases) { e in Button(e.name(store.language == .bulgarian)) { selected=e } }
                }
            }
            ForEach(filtered) { e in
                NavigationLink { ExerciseDetailView(exercise:e) } label {
                    VStack(alignment:.leading) {
                        Text(store.language == .english ? e.titleEN : e.titleBG).font(.headline)
                        Text("\(e.category) • \(e.duration) min").font(.caption).foregroundStyle(.secondary)
                    }
                }
            }
        }.navigationTitle(store.t("Training","Тренировки"))
    }
}
