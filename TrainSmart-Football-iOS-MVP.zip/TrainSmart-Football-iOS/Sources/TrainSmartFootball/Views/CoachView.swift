import SwiftUI

struct CoachView:View {
    @EnvironmentObject var store:AppStore
    @State private var question=""
    @State private var category="Technical"
    var body:some View {
        Form {
            Section(store.t("Ask Coach","Питай треньор")) {
                TextEditor(text:$question).frame(minHeight:130)
                Picker(store.t("Category","Категория"),selection:$category) { Text("Technical").tag("Technical");Text("Physical").tag("Physical");Text("General").tag("General") }
                Button(store.t("Send Question","Изпрати въпрос")) { store.submitQuestion(question,category:category);question="" }
            }
            Section(store.t("My Questions","Моите въпроси")) {
                if store.questions.isEmpty { Text(store.t("No questions yet.","Все още няма въпроси.")).foregroundStyle(.secondary) }
                ForEach(store.questions) { q in VStack(alignment:.leading){Text(q.question).font(.headline);Text("\(q.category) • \(q.status.rawValue.capitalized)").font(.caption).foregroundStyle(.secondary)} }
            }
        }.navigationTitle(store.t("Ask Coach","Питай треньор"))
    }
}
