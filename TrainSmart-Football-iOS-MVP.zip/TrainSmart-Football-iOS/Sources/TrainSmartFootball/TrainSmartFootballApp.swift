import SwiftUI

@main
struct TrainSmartFootballApp: App {
    @StateObject private var store = AppStore()
    var body: some Scene {
        WindowGroup { RootTabView().environmentObject(store) }
    }
}
