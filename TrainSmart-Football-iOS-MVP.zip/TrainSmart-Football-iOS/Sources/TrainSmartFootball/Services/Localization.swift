import Foundation
enum AppLanguage: String, CaseIterable, Identifiable { case english = "en", bulgarian = "bg"; var id: String { rawValue } }
func tr(_ language: AppLanguage, _ en: String, _ bg: String) -> String { language == .english ? en : bg }
