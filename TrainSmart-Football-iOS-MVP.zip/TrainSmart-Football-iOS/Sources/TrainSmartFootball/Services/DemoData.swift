import Foundation

enum DemoData {
    static func make(_ en: String, _ bg: String, _ cat: String, _ type: TrainingType, _ diff: Difficulty, _ min: Int, _ eq: [Equipment]) -> Exercise {
        Exercise(id: UUID(), titleEN: en, titleBG: bg, descriptionEN: "Football-specific individual drill.", descriptionBG: "Индивидуално футболно упражнение.",
                  category: cat, trainingType: type, difficulty: diff, duration: min, sets: 3, repetitions: 10, equipment: eq,
                  instructionsEN: ["Set up safely.", "Perform with quality and control.", "Rest briefly and repeat."],
                  instructionsBG: ["Подготви безопасно пространство.", "Изпълнявай качествено и контролирано.", "Почини кратко и повтори."])
    }
    static let exercises: [Exercise] = [
        make("Ball Mastery Foundations","Основи на владеенето","Ball Mastery",.technical,.beginner,10,[.ball]),
        make("First Touch Gate","Първо докосване през вратички","First Touch",.technical,.beginner,12,[.ball,.cones]),
        make("Close Control Dribble","Дрибъл с близък контрол","Dribbling",.technical,.intermediate,15,[.ball,.cones]),
        make("Weak Foot Passing","Пас с по-слаб крак","Passing",.technical,.intermediate,15,[.ball]),
        make("Inside-Out Touches","Докосвания вътре-вън","Ball Control",.technical,.intermediate,10,[.ball]),
        make("1v1 Change of Direction","Смяна на посока 1v1","Dribbling",.technical,.advanced,15,[.ball,.cones]),
        make("Finishing Targets","Завършване към цели","Shooting",.technical,.intermediate,20,[.ball,.cones]),
        make("Speed With Ball","Скорост с топка","Speed With Ball",.technical,.advanced,12,[.ball,.cones]),
        make("Acceleration Burst","Ускорения","Acceleration",.physical,.intermediate,12,[.cones]),
        make("Lateral Agility","Странична ловкост","Agility",.physical,.intermediate,12,[.cones]),
        make("Bodyweight Squat","Клек със собствено тегло","Strength",.physical,.beginner,10,[.bodyweight]),
        make("Single-Leg Balance","Баланс на един крак","Balance",.physical,.beginner,8,[.balance]),
        make("Core Plank","Планк за корем","Core",.physical,.beginner,8,[.mat]),
        make("Resistance Band Drive","Ускорение с ластик","Strength",.physical,.advanced,12,[.resistanceBand]),
        make("Mobility Flow","Мобилност","Mobility",.physical,.beginner,10,[.mat]),
        make("Endurance Shuttle","Челно бягане за издръжливост","Endurance",.physical,.intermediate,18,[.cones])
    ]
    static let plans: [TrainingPlan] = [
        TrainingPlan(id: UUID(),titleEN:"Ball Mastery — Beginner",titleBG:"Владеене на топката — Начинаещи",descriptionEN:"Build confident control and first touch.",descriptionBG:"Изгради уверен контрол и първо докосване.",weeks:4,difficulty:.beginner,objectiveEN:"Ball control",objectiveBG:"Контрол на топката",sessionExerciseIDs:Array(exercises.prefix(5).map(\.id))),
        TrainingPlan(id: UUID(),titleEN:"Technical Development — 4 Weeks",titleBG:"Техническо развитие — 4 седмици",descriptionEN:"Improve dribbling, passing and finishing.",descriptionBG:"Подобри дрибъла, паса и завършването.",weeks:4,difficulty:.intermediate,objectiveEN:"Technical skills",objectiveBG:"Технически умения",sessionExerciseIDs:Array(exercises.prefix(8).map(\.id))),
        TrainingPlan(id: UUID(),titleEN:"Speed & Agility — 4 Weeks",titleBG:"Скорост и ловкост — 4 седмици",descriptionEN:"Develop acceleration and movement quality.",descriptionBG:"Развий ускорението и качеството на движението.",weeks:4,difficulty:.intermediate,objectiveEN:"Athletic performance",objectiveBG:"Атлетично представяне",sessionExerciseIDs:Array(exercises.suffix(8).map(\.id)))
    ]
    static let achievements = [
        Achievement(id:UUID(),titleEN:"First Training",titleBG:"Първа тренировка",icon:"figure.run",requirement:1),
        Achievement(id:UUID(),titleEN:"3 Day Streak",titleBG:"3 дни серия",icon:"flame.fill",requirement:3),
        Achievement(id:UUID(),titleEN:"7 Day Streak",titleBG:"7 дни серия",icon:"flame.fill",requirement:7),
        Achievement(id:UUID(),titleEN:"10 Sessions Completed",titleBG:"10 завършени сесии",icon:"10.circle.fill",requirement:10),
        Achievement(id:UUID(),titleEN:"Ball Master",titleBG:"Майстор на топката",icon:"soccerball",requirement:5)
    ]
}
