import Foundation
import SwiftUI

@MainActor
final class AppStore: ObservableObject {
    @Published var language: AppLanguage = .english
    @Published var profile = PlayerProfile()
    @Published var exercises = DemoData.exercises
    @Published var plans = DemoData.plans
    @Published var achievements = DemoData.achievements
    @Published private(set) var completedExerciseIDs: Set<UUID> = []
    @Published private(set) var questions: [CoachQuestion] = []

    var completedCount: Int { completedExerciseIDs.count }
    var streak: Int { completedCount == 0 ? 0 : min(completedCount, 7) }
    func complete(_ exercise: Exercise) { completedExerciseIDs.insert(exercise.id) }
    func submitQuestion(_ text: String, category: String) {
        guard !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
        questions.insert(CoachQuestion(id: UUID(), question: text, category: category, date: Date(), status: .pending), at: 0)
    }
    func t(_ en: String, _ bg: String) -> String { tr(language, en, bg) }
}
