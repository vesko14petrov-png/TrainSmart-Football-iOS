# TrainSmart Football iOS

Native SwiftUI MVP source scaffold based on the current 10x development checkpoint.

Included:
- Home, Training, Progress, Ask Coach, Profile
- Technical and Physical training
- 16 demo exercises
- 3 training plans
- Exercise completion and streak state
- Progress and achievements
- Private Ask Coach Q&A (no chat/community)
- English/Bulgarian localization
- Equipment filters
- Profile/recommendation foundation
- Repository/service abstractions ready for Supabase

This is source code, not an exported Xcode project from 10x. Use it as the clean GitHub/Claude Code starting point. iOS build/App Store work requires Xcode on a Mac.
