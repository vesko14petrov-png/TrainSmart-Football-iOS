// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "TrainSmartFootball",
    platforms: [.iOS(.v17)],
    products: [.library(name: "TrainSmartFootball", targets: ["TrainSmartFootball"])],
    targets: [.target(name: "TrainSmartFootball", path: "Sources/TrainSmartFootball")]
)
