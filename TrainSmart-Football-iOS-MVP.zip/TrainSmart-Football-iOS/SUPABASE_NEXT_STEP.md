# Supabase next step

The MVP uses local demo data. Later:
1. Add Supabase Auth.
2. Add player_profiles, exercises, training_plans, training_sessions, training_session_exercises, completed_exercises, progress_metrics, achievements, user_achievements, coach_questions and coach_answers.
3. Implement the repository protocols with Supabase-backed services.
4. Keep views dependent on AppStore/services, never directly on Supabase.
5. Add Row Level Security for private player and coach-question data.
6. Never commit Supabase secrets.
